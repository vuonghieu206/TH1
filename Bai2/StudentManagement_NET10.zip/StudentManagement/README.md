# Bài thực hành 1 - Quản lý sinh viên (ASP.NET Core MVC .NET 10)

## Chức năng
- Hiển thị 4 sinh viên mẫu.
- Thêm sinh viên mới, tự tăng mã sinh viên.
- Chọn ngành học bằng dropdown, giới tính bằng radio button, hệ đào tạo bằng checkbox.
- Upload ảnh đại diện (JPG/JPEG/PNG/GIF/WEBP, tối đa 5 MB).
- Route danh sách: `/Admin/Student/List`.
- Route thêm mới: `/Admin/Student/Add`.

## Chạy chương trình
1. Mở `StudentManagement.csproj` bằng Visual Studio 2026 hoặc IDE hỗ trợ .NET 10.
2. Restore và chạy project (F5).
3. Mở `/Admin/Student/List` hoặc `/Admin/Student/Add`.

Dữ liệu đang lưu trong danh sách static ở bộ nhớ; khởi động lại ứng dụng sẽ trở về 4 sinh viên mẫu. Đây là cách phù hợp với yêu cầu thực hành chưa dùng cơ sở dữ liệu.
