using Microsoft.AspNetCore.Mvc;
using MyWebApp.Models;

namespace MyWebApp.Controllers;

public class StudentController : Controller
{
    // Dữ liệu lưu trong bộ nhớ: sẽ được làm mới khi khởi động lại ứng dụng.
    private static readonly List<Student> listStudents = new()
    {
        new Student { Id = 101, Name = "Hải Nam", Branch = Branch.IT, Gender = Gender.Male, IsRegular = true, Address = "A1-2018", Email = "nam@g.com", DateOfBirth = new DateTime(2004, 1, 1) },
        new Student { Id = 102, Name = "Minh Tú", Branch = Branch.BE, Gender = Gender.Female, IsRegular = true, Address = "A1-2019", Email = "tu@g.com", DateOfBirth = new DateTime(2004, 2, 12) },
        new Student { Id = 103, Name = "Hoàng Phong", Branch = Branch.CE, Gender = Gender.Male, IsRegular = false, Address = "A1-2020", Email = "phong@g.com", DateOfBirth = new DateTime(2003, 6, 20) },
        new Student { Id = 104, Name = "Xuân Mai", Branch = Branch.EE, Gender = Gender.Female, IsRegular = false, Address = "A1-2021", Email = "mai@g.com", DateOfBirth = new DateTime(2004, 9, 8) }
    };

    [HttpGet]
    public IActionResult Index() => View(listStudents);

    [HttpGet]
    public IActionResult Create()
    {
        ViewBag.AllGenders = Enum.GetValues<Gender>();
        return View(new Student { DateOfBirth = DateTime.Today, IsRegular = true });
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Create(Student s, IFormFile? AvatarFile)
    {
        if (AvatarFile is { Length: > 0 })
        {
            var allowed = new[] { ".jpg", ".jpeg", ".png", ".gif", ".webp" };
            var ext = Path.GetExtension(AvatarFile.FileName).ToLowerInvariant();
            if (!allowed.Contains(ext))
                ModelState.AddModelError(nameof(AvatarFile), "Chỉ chấp nhận ảnh JPG, JPEG, PNG, GIF hoặc WEBP.");
            else if (AvatarFile.Length > 5 * 1024 * 1024)
                ModelState.AddModelError(nameof(AvatarFile), "Ảnh không được vượt quá 5 MB.");
            else
            {
                var uploadDir = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "uploads");
                Directory.CreateDirectory(uploadDir);
                var fileName = $"{Guid.NewGuid():N}{ext}";
                var filePath = Path.Combine(uploadDir, fileName);
                await using var stream = new FileStream(filePath, FileMode.Create);
                await AvatarFile.CopyToAsync(stream);
                s.AvatarPath = "/uploads/" + fileName;
            }
        }

        if (!ModelState.IsValid)
        {
            ViewBag.AllGenders = Enum.GetValues<Gender>();
            return View(s);
        }

        s.Id = listStudents.Count == 0 ? 101 : listStudents.Max(x => x.Id) + 1;
        listStudents.Add(s);
        return RedirectToAction(nameof(Index));
    }
}
